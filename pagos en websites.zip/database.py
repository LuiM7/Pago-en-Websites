import sqlite3

DATABASE = 'tienda.db'

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()

    cursor.executescript('''
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            contrasena TEXT NOT NULL,
            fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS productos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            descripcion TEXT,
            precio REAL NOT NULL,
            imagen TEXT,
            stock INTEGER DEFAULT 10
        );

        CREATE TABLE IF NOT EXISTS ordenes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER,
            total REAL NOT NULL,
            estado TEXT DEFAULT 'pendiente',
            stripe_session_id TEXT,
            fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        );

        CREATE TABLE IF NOT EXISTS orden_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            orden_id INTEGER,
            producto_id INTEGER,
            cantidad INTEGER NOT NULL,
            precio_unitario REAL NOT NULL,
            FOREIGN KEY (orden_id) REFERENCES ordenes(id),
            FOREIGN KEY (producto_id) REFERENCES productos(id)
        );
    ''')

    cursor.execute('SELECT COUNT(*) FROM productos')
    if cursor.fetchone()[0] == 0:
        productos_demo = [
            ('Laptop Gamer Pro',    'Intel i9, RTX 4070, 32GB RAM, 1TB SSD',          45000.00, '💻'),
            ('Mouse Inalámbrico',   'Ergonómico, 6 botones, 3200 DPI, sin lag',         1200.00, '🖱️'),
            ('Teclado Mecánico',    'Switches Blue, retroiluminación RGB, TKL',         3500.00, '⌨️'),
            ('Monitor 4K 27"',      '4K UHD, 144Hz, 1ms, panel IPS, FreeSync',        18000.00, '🖥️'),
            ('Auriculares Gaming',  'Sonido 7.1 envolvente, micrófono desmontable',     2800.00, '🎧'),
            ('Webcam Full HD',      '1080p 60fps, autofocus, ideal para streaming',     1800.00, '📷'),
        ]
        cursor.executemany(
            'INSERT INTO productos (nombre, descripcion, precio, imagen) VALUES (?, ?, ?, ?)',
            productos_demo
        )

    conn.commit()
    conn.close()
