from flask import Flask, render_template, request, session, redirect, url_for
from database import init_db, get_db
from auth import hash_password, verify_password, create_token, verify_token
import stripe
import os
from dotenv import load_dotenv
from functools import wraps

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'clave-secreta-dev-2024')
stripe.api_key = os.getenv('STRIPE_SECRET_KEY', 'sk_test_COLOCA_TU_CLAVE_AQUI')
STRIPE_PK = os.getenv('STRIPE_PUBLISHABLE_KEY', 'pk_test_COLOCA_TU_CLAVE_AQUI')
DOMAIN = os.getenv('DOMAIN', 'http://localhost:5000')

with app.app_context():
    init_db()

# ─────────────────────────────────────────────────────────────────────────────
# HELPER: obtener usuario actual desde la sesión
# ─────────────────────────────────────────────────────────────────────────────
def get_current_user():
    return verify_token(session.get('token', ''))

def get_cart_count():
    return sum(session.get('carrito', {}).values())

# ─────────────────────────────────────────────────────────────────────────────
# RUTAS PRINCIPALES
# ─────────────────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    db = get_db()
    productos = db.execute('SELECT * FROM productos').fetchall()
    db.close()
    return render_template('index.html',
                           productos=productos,
                           user=get_current_user(),
                           cart_count=get_cart_count())

# ─────────────────────────────────────────────────────────────────────────────
# AUTENTICACIÓN
# ─────────────────────────────────────────────────────────────────────────────
@app.route('/registro', methods=['GET', 'POST'])
def registro():
    if request.method == 'POST':
        nombre   = request.form.get('nombre', '').strip()
        email    = request.form.get('email', '').strip()
        password = request.form.get('password', '')

        if not all([nombre, email, password]):
            return render_template('registro.html', error='Todos los campos son obligatorios.')

        if len(password) < 6:
            return render_template('registro.html', error='La contraseña debe tener al menos 6 caracteres.')

        db = get_db()
        existe = db.execute('SELECT id FROM usuarios WHERE email = ?', (email,)).fetchone()

        if existe:
            db.close()
            return render_template('registro.html', error='Ese email ya está registrado.')

        contrasena_hash = hash_password(password)
        db.execute('INSERT INTO usuarios (nombre, email, contrasena) VALUES (?, ?, ?)',
                   (nombre, email, contrasena_hash))
        db.commit()
        db.close()

        return redirect(url_for('login', success='1'))

    return render_template('registro.html', user=None, cart_count=get_cart_count())

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email    = request.form.get('email', '').strip()
        password = request.form.get('password', '')

        db = get_db()
        usuario = db.execute('SELECT * FROM usuarios WHERE email = ?', (email,)).fetchone()
        db.close()

        if not usuario or not verify_password(password, usuario['contrasena']):
            return render_template('login.html', error='Email o contraseña incorrectos.')

        token = create_token(usuario['id'], usuario['email'])
        session['token']  = token
        session['nombre'] = usuario['nombre']

        return redirect(url_for('index'))

    success = request.args.get('success')
    return render_template('login.html',
                           success='Cuenta creada. Inicia sesión.' if success else None,
                           user=None,
                           cart_count=get_cart_count())

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

# ─────────────────────────────────────────────────────────────────────────────
# CARRITO
# ─────────────────────────────────────────────────────────────────────────────
@app.route('/carrito')
def carrito():
    carrito_session = session.get('carrito', {})
    items = []
    total = 0

    if carrito_session:
        db = get_db()
        for producto_id, cantidad in carrito_session.items():
            producto = db.execute('SELECT * FROM productos WHERE id = ?', (producto_id,)).fetchone()
            if producto:
                subtotal = producto['precio'] * cantidad
                total   += subtotal
                items.append({
                    'id':       producto['id'],
                    'nombre':   producto['nombre'],
                    'precio':   producto['precio'],
                    'imagen':   producto['imagen'],
                    'cantidad': cantidad,
                    'subtotal': subtotal,
                })
        db.close()

    return render_template('carrito.html',
                           items=items,
                           total=total,
                           user=get_current_user(),
                           cart_count=get_cart_count(),
                           stripe_pk=STRIPE_PK)

@app.route('/carrito/agregar', methods=['POST'])
def agregar_carrito():
    producto_id = str(request.form.get('producto_id'))
    cantidad    = int(request.form.get('cantidad', 1))

    if 'carrito' not in session:
        session['carrito'] = {}

    carrito = session['carrito']
    carrito[producto_id] = carrito.get(producto_id, 0) + cantidad
    session['carrito']   = carrito
    session.modified     = True

    return redirect(url_for('carrito'))

@app.route('/carrito/eliminar/<producto_id>')
def eliminar_carrito(producto_id):
    carrito = session.get('carrito', {})
    carrito.pop(producto_id, None)
    session['carrito'] = carrito
    session.modified   = True
    return redirect(url_for('carrito'))

@app.route('/carrito/vaciar')
def vaciar_carrito():
    session.pop('carrito', None)
    return redirect(url_for('carrito'))

# ─────────────────────────────────────────────────────────────────────────────
# PAGOS CON STRIPE
# ─────────────────────────────────────────────────────────────────────────────
@app.route('/crear-sesion-pago', methods=['POST'])
def crear_sesion_pago():
    carrito_session = session.get('carrito', {})

    if not carrito_session:
        return redirect(url_for('carrito'))

    db = get_db()
    line_items = []

    for producto_id, cantidad in carrito_session.items():
        producto = db.execute('SELECT * FROM productos WHERE id = ?', (producto_id,)).fetchone()
        if producto:
            line_items.append({
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': producto['nombre'],
                        'description': producto['descripcion'],
                    },
                    'unit_amount': int(producto['precio'] * 100),
                },
                'quantity': cantidad,
            })
    db.close()

    if not line_items:
        return redirect(url_for('carrito'))

    try:
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=line_items,
            mode='payment',
            success_url=DOMAIN + '/pago-exitoso?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=DOMAIN + '/pago-cancelado',
        )

        user  = get_current_user()
        total = sum(i['price_data']['unit_amount'] * i['quantity'] / 100 for i in line_items)

        conn = get_db()
        conn.execute(
            'INSERT INTO ordenes (usuario_id, total, stripe_session_id) VALUES (?, ?, ?)',
            (user['user_id'] if user else None, total, checkout_session.id)
        )
        conn.commit()
        conn.close()

        return redirect(checkout_session.url, code=303)

    except Exception as e:
        items = []
        total = 0
        return render_template('carrito.html',
                               items=items,
                               total=total,
                               error=f'Error al conectar con Stripe: {str(e)}',
                               user=get_current_user(),
                               cart_count=get_cart_count(),
                               stripe_pk=STRIPE_PK)

@app.route('/pago-exitoso')
def pago_exitoso():
    session_id = request.args.get('session_id')

    if session_id:
        db = get_db()
        db.execute("UPDATE ordenes SET estado = 'completado' WHERE stripe_session_id = ?",
                   (session_id,))
        db.commit()
        db.close()

    session.pop('carrito', None)
    return render_template('pago_exitoso.html', user=get_current_user(), cart_count=0)

@app.route('/pago-cancelado')
def pago_cancelado():
    return render_template('pago_cancelado.html',
                           user=get_current_user(),
                           cart_count=get_cart_count())

# ─────────────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    app.run(debug=True)
